from distutils.core import setup, Extension
import os
setup(name = 'foo', version = '1.0', ext_modules = [Extension('foo', ['testsm3.c'])])
cmd = "rm -rf build"
os.system (cmd)
