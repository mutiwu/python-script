
import SM3

s1=SM3.strenc ("123");
print s1

#data=[1,2,3]
##s2=SM3.hexenc (data)
#print s2
