#include <openssl/evp.h>
#include <Python.h>
#include <string.h>


#if 0
int strencrypt (const char* instr, char** outstr) {
    
    EVP_MD_CTX mdctx;
    const EVP_MD *md;
    unsigned char md_value[EVP_MAX_MD_SIZE];
    char formatstr[EVP_MAX_MD_SIZE * 2];
	*outstr=malloc (64);
    char *alg="sm3";
    unsigned int md_len;
    int i;
    OpenSSL_add_all_digests();
    md=EVP_get_digestbyname(alg);
    if(!md)
    {
        return -1;
    }
    EVP_MD_CTX_init(&mdctx);
    EVP_DigestInit_ex(&mdctx,md,NULL);
    EVP_DigestUpdate(&mdctx,instr,strlen(instr));
    EVP_DigestFinal_ex(&mdctx,md_value,&md_len);
    for (i=0;i<md_len;i++){
	sprintf (*outstr+i*2,"%02x",md_value[i]);
    }
    EVP_MD_CTX_cleanup(&mdctx);
    return 0;
}
#endif


int strencrypt (const char* instr, char* outstr) {
	
	unsigned char tmp[32];
	int res;
	int len;
	int i;
	len = strlen (instr);
	res = encrypt (instr, tmp, &len);
    	for (i=0; i < len; i++){
		sprintf (outstr + i * 2,"%02x",tmp[i]);
    	}
	return res;
}

int hexencrypt (const char* instr, char* outstr, int* len) {
	
	return encrypt (instr, outstr, len);
}


int encrypt (char* instr, char* outstr, int* len) {

    EVP_MD_CTX mdctx;
    const EVP_MD *md;
    char *alg="sm3";
    OpenSSL_add_all_digests();
    md=EVP_get_digestbyname(alg);
    if(!md)
    {
        return -1;
    }
    EVP_MD_CTX_init(&mdctx);
    EVP_DigestInit_ex(&mdctx,md,NULL);
    EVP_DigestUpdate(&mdctx,instr,*len);
    EVP_DigestFinal_ex(&mdctx,outstr,len);
    EVP_MD_CTX_cleanup(&mdctx);
    return 0;
}


static PyObject* SM3_strencrypt (PyObject* self, PyObject* argv) {

	PyObject* rtvl;
	char* instr;
	char* outstr;
	int res;
	outstr = malloc (64);
	PyArg_ParseTuple(argv, "s", &instr);
	res = strencrypt (instr, outstr);
	rtvl = (PyObject *)Py_BuildValue("is", res, outstr);
	return rtvl;
}



static PyObject* SM3_hexencrypt (PyObject* self, PyObject* argv) {

        PyObject* rtvl;
        char* instr;
        char* outstr;
        int res;
	int len;
	outstr = malloc (32);
        PyArg_ParseTuple(argv, "si", &instr, &len);
        res = hexencrypt (instr, outstr, &len);
        rtvl = (PyObject *)Py_BuildValue("is", res, outstr);
        return rtvl;
}

PyMethodDef methods[]={
	
	{"strenc", SM3_strencrypt, METH_VARARGS,"sm3 string encrypt"},
//	{"hexenc", SM3_hexencrypt, METH_VARARGS,"sm3 hex encrypt"},
	{NULL,NULL,0,NULL}
};

PyMODINIT_FUNC initSM3() {
    Py_InitModule("SM3", methods);
}

