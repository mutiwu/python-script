#include <Python.h>
#include <stdio.h>

static PyObject* bar (PyObject* sele, PyObject* argv) {

	printf ("c extend test1\n");
	Py_RETURN_NONE;
}

PyMethodDef foo_Methods[] = {

	{"bar", bar, METH_VARARGS, "first c extend"},
	{NULL, NULL, 0, NULL}

};

PyMODINIT_FUNC initfoo() {
    Py_InitModule3("foo", foo_Methods,"hello");
}
